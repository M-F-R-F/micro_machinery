package com.dbydd.micro_machinery.blocks;

public class OreNether extends BlockOres {

	public OreNether(String name, int harvestlevel, float hardness) {
		super(name+"_Nether", harvestlevel, hardness);
		// TODO Auto-generated constructor stub
	}
	
}
