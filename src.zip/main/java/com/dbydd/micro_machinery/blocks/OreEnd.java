package com.dbydd.micro_machinery.blocks;

public class OreEnd extends BlockOres{

	public OreEnd(String name, int harvestlevel, float hardness) {
		super(name+"_End", harvestlevel, hardness);
		// TODO Auto-generated constructor stub
	}
	
}
