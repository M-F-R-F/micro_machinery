package com.dbydd.micro_machinery.util;

public interface IHasModel 
{

	public void registerModels();
	
}
